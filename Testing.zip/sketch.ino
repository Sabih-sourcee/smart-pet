
#include <ESP32Servo.h>

Servo myServo;

const int servoPin = 5;
const int buttonPin = 4;

bool servoPosition = false;

int lastButtonState = HIGH;
int currentButtonState = HIGH;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 50;

void setup() {
  Serial.begin(115200);

  pinMode(buttonPin, INPUT_PULLUP);

  myServo.attach(servoPin);
  myServo.write(0);

  Serial.println("ScreenMate Controller V2 Ready!");
  Serial.println("Servo Position: 0 degrees");
}

void loop() {

  int reading = digitalRead(buttonPin);

  if (reading != lastButtonState) {
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > debounceDelay) {

    if (reading != currentButtonState) {

      currentButtonState = reading;

      if (currentButtonState == LOW) {

        servoPosition = !servoPosition;

        if (servoPosition) {
          myServo.write(90);
          Serial.println("Servo Position: 90 degrees");
        }
        else {
          myServo.write(0);
          Serial.println("Servo Position: 0 degrees");
        }
      }
    }
  }

  lastButtonState = reading;
}
